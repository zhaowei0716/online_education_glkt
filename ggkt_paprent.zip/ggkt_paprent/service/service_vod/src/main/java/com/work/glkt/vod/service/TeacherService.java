package com.work.glkt.vod.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.work.glkt.model.vod.Teacher;

/**
 * <p>
 * 讲师 服务类
 * </p>
 *
 * @author wzhao
 * @since 2022-08-11
 */
public interface TeacherService extends IService<Teacher> {

}
