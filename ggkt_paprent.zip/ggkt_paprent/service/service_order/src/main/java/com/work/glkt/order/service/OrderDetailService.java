package com.work.glkt.order.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.work.glkt.model.order.OrderDetail;

/**
 * <p>
 * 订单明细 订单明细 服务类
 * </p>
 *
 * @author wzhao
 * @since 2022-08-19
 */
public interface OrderDetailService extends IService<OrderDetail> {

}
