package com.work.glkt.wechat.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.work.glkt.model.wechat.Menu;

/**
 * <p>
 * 订单明细 订单明细 Mapper 接口
 * </p>
 *
 * @author wzhao
 * @since 2022-08-22
 */
public interface MenuMapper extends BaseMapper<Menu> {

}
