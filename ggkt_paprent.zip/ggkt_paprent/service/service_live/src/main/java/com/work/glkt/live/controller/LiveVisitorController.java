package com.work.glkt.live.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 直播来访者记录表 前端控制器
 * </p>
 *
 * @author wzhao
 * @since 2022-08-24
 */
@RestController
@RequestMapping("/live/live-visitor")
public class LiveVisitorController {

}


